import React from 'react'
import "./footer.css"

function Footer() {
  return (
    <div className='footer'>
      <h4> by Afshin Izadnia (^_^) </h4>
      </div>
  )
}

export default Footer